import pytest
import time
import math
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class TestStepikAlien:

    @pytest.fixture(scope="class")
    def browser(self):
        print("\nstart browser for test..")
        browser = webdriver.Chrome()

        # Авторизация один раз для всех тестов
        browser.get("https://stepik.org/catalog")
        time.sleep(2)

        try:
            login_button = WebDriverWait(browser, 5).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, ".navbar__auth_login"))
            )
            login_button.click()

            email_input = WebDriverWait(browser, 5).until(
                EC.presence_of_element_located((By.ID, "id_login_email"))
            )
            email_input.send_keys("keslolorbidol@gmail.com")

            password_input = browser.find_element(By.ID, "id_login_password")
            password_input.send_keys("kolleg54")

            submit_button = browser.find_element(By.CSS_SELECTOR, "button[type='submit']")
            submit_button.click()

            time.sleep(5)  # Ждем завершения авторизации
        except:
            pass  # Уже авторизованы

        yield browser
        print("\nquit browser..")
        browser.quit()

    @pytest.mark.parametrize('lesson', [
        "236895", "236896", "236897", "236898", "236899", "236903", "236904", "236905"
    ])
    def test_stepik_alien_message(self, browser, lesson):
        link = f"https://stepik.org/lesson/{lesson}/step/1"
        browser.get(link)
        time.sleep(2)

        # Вычисляем ответ
        answer = math.log(int(time.time()))

        # Ждем появления поля ввода и вводим ответ
        answer_input = WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".ember-text-area"))
        )

        # Очищаем поле перед вводом
        answer_input.clear()
        answer_input.send_keys(str(answer))

        # Нажимаем кнопку "Отправить"
        submit_button = WebDriverWait(browser, 5).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, ".submit-submission"))
        )
        submit_button.click()

        # Ждем фидбека
        feedback = WebDriverWait(browser, 10).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, ".smart-hints__hint"))
        )

        feedback_text = feedback.text

        assert feedback_text == "Correct!", \
            f"Unexpected feedback text: {feedback_text}"


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
