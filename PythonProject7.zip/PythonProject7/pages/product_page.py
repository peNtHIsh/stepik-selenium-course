from .base_page import BasePage
from .locators import ProductPageLocators


class ProductPage(BasePage):
    def add_to_basket(self):
        button = self.browser.find_element(*ProductPageLocators.ADD_TO_BASKET_BUTTON)
        button.click()

    def get_product_name(self):
        """Получить название товара со страницы"""
        return self.browser.find_element(*ProductPageLocators.PRODUCT_NAME).text

    def get_product_price(self):
        """Получить цену товара со страницы"""
        return self.browser.find_element(*ProductPageLocators.PRODUCT_PRICE).text

    def get_success_message_product_name(self):
        """Получить название товара из сообщения об успешном добавлении"""
        return self.browser.find_element(*ProductPageLocators.SUCCESS_MESSAGE).text

    def get_basket_total(self):
        """Получить стоимость корзины из сообщения"""
        return self.browser.find_element(*ProductPageLocators.BASKET_TOTAL).text

    def should_be_success_message(self):
        """Проверить, что есть сообщение об успешном добавлении"""
        assert self.is_element_present(*ProductPageLocators.SUCCESS_MESSAGE), \
            "Success message is not presented"

    def should_be_correct_product_in_message(self):
        """Проверить, что название товара в сообщении совпадает с добавленным товаром"""
        product_name = self.get_product_name()
        message_product_name = self.get_success_message_product_name()
        assert product_name == message_product_name, \
            f"Product name in message '{message_product_name}' does not match actual product name '{product_name}'"

    def should_be_correct_basket_total(self):
        """Проверить, что цена корзины совпадает с ценой товара"""
        product_price = self.get_product_price()
        basket_total = self.get_basket_total()
        assert product_price == basket_total, \
            f"Basket total '{basket_total}' does not match product price '{product_price}'"

    def should_not_be_success_message(self):
        """Проверяет, что сообщение об успехе НЕ появляется"""
        assert self.is_not_element_present(*ProductPageLocators.SUCCESS_MESSAGE), \
            "Success message is presented, but should not be"

    def should_disappeared_success_message(self):
        """Проверяет, что сообщение об успехе исчезает"""
        assert self.is_disappeared(*ProductPageLocators.SUCCESS_MESSAGE), \
            "Success message did not disappear"
